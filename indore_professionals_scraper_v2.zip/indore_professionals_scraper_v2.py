import os
import re
import time
from urllib.parse import quote_plus

import pandas as pd
from playwright.sync_api import sync_playwright

# ============================================================
# CONFIGURATION
# ============================================================
OUTPUT_DIR = r"C:\scrapper_doc"
os.makedirs(OUTPUT_DIR, exist_ok=True)

FINAL_FILE = os.path.join(OUTPUT_DIR, "indore_professionals.xlsx")
LIVE_FILE = os.path.join(OUTPUT_DIR, "indore_professionals_LIVE_BACKUP.xlsx")
CSV_BACKUP = os.path.join(OUTPUT_DIR, "indore_professionals_LIVE_BACKUP.csv")

COLUMNS = ["Name", "Phone", "Address", "Website", "Rating", "Category", "Search"]

AREAS = [
    "Palasia", "Vijay Nagar", "LIG Colony", "Gumasta Nagar",
    "YN Road", "AB Road", "Bhawarkuan", "Rajwada",
    "Malviya Nagar", "Scheme 54", "Scheme 78", "New Palasia",
    "Sapna Sangeeta", "Geeta Bhawan", "South Tukoganj",
    "Mahalaxmi Nagar", "Silicon City", "Nipania", "Rau",
    "Bengali Square", "Annapurna", "Tilak Nagar", "Bhanwarkuan",
    "Lasudia", "Khandwa Road", "Dewas Nagar", "Mhow Naka",
    "Aerodrome Road",
]

CATEGORIES = [
    "doctor", "clinic", "chartered accountant", "CA firm", "lawyer",
    "advocate", "manufacturer", "supplier", "wholesaler", "trader",
    "distributor", "electronics shop", "mobile shop", "clothing store",
    "furniture shop", "hardware store", "construction material supplier",
    "automobile dealer", "jewellery shop", "food supplier",
    "packaging company", "chemical supplier", "plastic manufacturer",
    "printing press", "engineering company", "electrical shop",
    "property dealer", "coaching institute", "IT company", "pvt ltd company",
]

SEARCHES = [
    f"{category} in {area} Indore"
    for category in CATEGORIES
    for area in AREAS
]


def detect_category(query):
    q = query.lower()
    if any(k in q for k in ["doctor", "clinic"]):
        return "Doctor - Clinic"
    if any(k in q for k in ["chartered accountant", "ca firm"]):
        return "Chartered Accountant"
    if any(k in q for k in ["lawyer", "advocate"]):
        return "Lawyer"
    if "manufacturer" in q:
        return "Manufacturer"
    if any(k in q for k in ["supplier", "wholesaler", "trader", "distributor"]):
        return "Supplier - Trader"
    if any(k in q for k in ["electronics", "mobile shop"]):
        return "Electronics"
    if "clothing" in q:
        return "Clothing"
    if "furniture" in q:
        return "Furniture"
    if any(k in q for k in ["hardware", "construction material"]):
        return "Hardware - Construction"
    if "automobile" in q:
        return "Automobile"
    if "jewellery" in q:
        return "Jewellery"
    if "food supplier" in q:
        return "Food Supplier"
    if "packaging" in q:
        return "Packaging"
    if any(k in q for k in ["chemical", "plastic"]):
        return "Chemical - Plastic"
    if "printing" in q:
        return "Printing"
    if "engineering" in q:
        return "Engineering"
    if "electrical" in q:
        return "Electrical"
    if "property dealer" in q:
        return "Property Dealer"
    if "coaching" in q:
        return "Coaching - Education"
    if "it company" in q:
        return "IT Company"
    if "pvt ltd" in q:
        return "Pvt Ltd Company"
    return "Business Owner"


def as_dataframe(records):
    df = pd.DataFrame(records)
    for col in COLUMNS:
        if col not in df.columns:
            df[col] = ""
    return df[COLUMNS]


def safe_sheet_name(category, used):
    name = re.sub(r'[\\/*?:\[\]]', "-", str(category)).strip("'")
    name = (name or "Category")[:31]
    base = name
    n = 1
    while name.casefold() in used:
        suffix = f"_{n}"
        name = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(name.casefold())
    return name


def save_live_backups(records):
    """Save the current in-memory records to XLSX and CSV after each search."""
    if not records:
        return

    df = as_dataframe(records)

    # CSV backup is written first, so there is a second recovery format.
    try:
        df.to_csv(CSV_BACKUP, index=False, encoding="utf-8-sig")
        print(f"  💾 CSV backup updated: {len(df)} records -> {CSV_BACKUP}")
    except Exception as exc:
        print(f"  ⚠ CSV backup failed: {type(exc).__name__}: {exc}")

    try:
        df.to_excel(LIVE_FILE, index=False, sheet_name="All Collected", engine="openpyxl")
        print(f"  💾 Excel live backup updated: {len(df)} records -> {LIVE_FILE}")
    except PermissionError:
        print("  ⚠ Close indore_professionals_LIVE_BACKUP.xlsx in Excel; CSV backup may still be available.")
    except Exception as exc:
        print(f"  ⚠ Excel live backup failed: {type(exc).__name__}: {exc}")


def export_final(records):
    if not records:
        print("No records collected; final workbook not created.")
        return

    df = as_dataframe(records)

    # Keep records with missing phones; only deduplicate nonblank phone numbers.
    df["Phone"] = df["Phone"].fillna("").astype(str).str.strip()
    has_phone = df[df["Phone"] != ""].drop_duplicates(subset=["Phone"], keep="first")
    no_phone = df[df["Phone"] == ""]
    df = pd.concat([has_phone, no_phone], ignore_index=True)
    df.drop_duplicates(subset=["Name"], keep="first", inplace=True)
    df.sort_values(["Category", "Name"], inplace=True, na_position="last")
    df.reset_index(drop=True, inplace=True)

    with pd.ExcelWriter(FINAL_FILE, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="All Professionals")
        used = {"all professionals"}
        for category in df["Category"].dropna().unique():
            sheet = safe_sheet_name(category, used)
            df[df["Category"] == category].to_excel(
                writer, index=False, sheet_name=sheet
            )

    print(f"\n✅ FINAL EXCEL SAVED: {FINAL_FILE}")
    print(f"Unique records in final report: {len(df)}")
    print(f"File size: {os.path.getsize(FINAL_FILE):,} bytes")


def scrape_google_maps(query, page):
    print(f"\nSearching: {query}")
    records = []
    category = detect_category(query)

    try:
        url = "https://www.google.com/maps/search/" + quote_plus(query)
        page.goto(url, timeout=60000, wait_until="domcontentloaded")
        time.sleep(3)

        for _ in range(6):
            panel = page.query_selector('div[role="feed"]')
            if panel:
                panel.evaluate("el => el.scrollBy(0, 1000)")
            else:
                page.keyboard.press("End")
            time.sleep(1.5)

        listings = page.query_selector_all('div[role="feed"] > div > div > a')
        print(f"  Found {len(listings)} listings")

        # Capture hrefs while the results panel is available.
        hrefs = []
        for listing in listings:
            try:
                href = listing.get_attribute("href")
                if href and href not in hrefs:
                    hrefs.append(href)
            except Exception:
                continue

        for href in hrefs:
            try:
                # Use a locator for the captured result link.
                locator = page.locator("a[href='" + href.replace("'", "\\'") + "']").first
                if locator.count() == 0:
                    continue
                locator.click(timeout=10000)
                time.sleep(2)

                def safe_text(selector):
                    try:
                        el = page.query_selector(selector)
                        return el.inner_text().strip() if el else None
                    except Exception:
                        return None

                name = safe_text("h1.DUwDvf")
                phone = safe_text('button[data-item-id*="phone"] div.rogA2c div')
                address = safe_text('button[data-item-id="address"] div.rogA2c div')
                website = safe_text('a[data-item-id="authority"] div.rogA2c div')
                rating = safe_text('div.F7nice span[aria-hidden="true"]')

                if not phone:
                    phone = safe_text('button[aria-label*="phone"] div.rogA2c div')
                if not address:
                    address = safe_text('button[aria-label*="Address"] div.rogA2c div')

                if name:
                    records.append({
                        "Name": name, "Phone": phone, "Address": address,
                        "Website": website, "Rating": rating,
                        "Category": category, "Search": query,
                    })
                    print(f"  ✅ {name} | {phone} | {address}")
                else:
                    print("  ⚠ Skipped — no name found")

                page.go_back(timeout=30000, wait_until="domcontentloaded")
                time.sleep(1.5)

            except Exception as exc:
                print(f"  ⚠ Listing error: {type(exc).__name__}: {exc}")
                try:
                    page.go_back(timeout=15000, wait_until="domcontentloaded")
                    time.sleep(1)
                except Exception:
                    pass

    except Exception as exc:
        print(f"  ❌ Search error: {type(exc).__name__}: {exc}")

    print(f"  → Collected {len(records)} records from this search")
    return records


def main():
    print("=" * 60)
    print("Indore Leads Scraper — live Excel and CSV backups")
    print(f"Queries: {len(SEARCHES)}")
    print(f"Output folder: {OUTPUT_DIR}")
    print(f"Live Excel backup: {LIVE_FILE}")
    print(f"Live CSV backup: {CSV_BACKUP}")
    print(f"Final Excel: {FINAL_FILE}")
    print("=" * 60)

    all_records = []

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            context = browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/126.0.0.0 Safari/537.36"
                ),
            )
            page = context.new_page()

            try:
                for i, query in enumerate(SEARCHES):
                    print(f"\n[{i + 1}/{len(SEARCHES)}]", end="")
                    records = scrape_google_maps(query, page)
                    all_records.extend(records)
                    print(f"  ► Total so far: {len(all_records)} records")

                    # Save after every search so a long run is recoverable.
                    save_live_backups(all_records)
                    time.sleep(2)
            finally:
                browser.close()

    except KeyboardInterrupt:
        print("\n⚠ Interrupted. Saving all records collected in this run...")
        save_live_backups(all_records)
        export_final(all_records)
        return
    except Exception as exc:
        print(f"\n❌ Run failed: {type(exc).__name__}: {exc}")
        print("Saving records collected in this run before exiting...")
        save_live_backups(all_records)
        if all_records:
            export_final(all_records)
        raise

    export_final(all_records)


if __name__ == "__main__":
    main()
